DECLARE
 v_char VARCHAR2(30);
 v_num NUMBER(11,2);
BEGIN
  v_char:= '42 is the answer';
  v_num := TO_NUMBER(SUBSTR(v_char,1,2));
  IF mod(v_num,2)=0 THEN
    INSERT INTO messages(results)
    VALUES('Number is even');
  ELSE
    INSERT INTO messages(results)
    VALUES('Number is old');
  END IF;
END;
/