VARIABLE g_message VARCHAR2(30)
BEGIN
  :g_message:='Hola Mundo';
END;
/
PRINT g_message